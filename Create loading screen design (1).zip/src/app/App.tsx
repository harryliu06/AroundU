import { LoadingScreen } from './components/LoadingScreen';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center">
      <LoadingScreen />
    </div>
  );
}