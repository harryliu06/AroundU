import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

export function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const totalAnts = 12;

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          return 0; // Loop the animation
        }
        return prev + 1;
      });
    }, 50);

    return () => clearInterval(interval);
  }, []);

  const filledAnts = Math.floor((progress / 100) * totalAnts);

  return (
    <div className="size-full flex flex-col items-center justify-center bg-[#f5f5f5]">
      {/* Anteater Image */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-12"
      >
        <img
          src="https://images.unsplash.com/photo-1754414433994-0ca569703893?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbnRlYXRlciUyMGFuaW1hbCUyMHNpZGUlMjB2aWV3fGVufDF8fHx8MTc3OTkzNTI2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Anteater"
          className="w-64 h-auto object-contain"
        />
      </motion.div>

      {/* Progress Bar with Ants */}
      <div className="mb-6">
        <div className="relative w-80 h-12 border-2 border-black rounded-full bg-white flex items-center justify-center px-2 overflow-hidden">
          {/* Ants */}
          <div className="flex gap-1 items-center justify-center">
            {Array.from({ length: totalAnts }).map((_, index) => (
              <motion.span
                key={index}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`text-lg leading-none transition-all duration-300 ${
                  index < filledAnts ? 'opacity-100' : 'opacity-30 grayscale'
                }`}
                style={{
                  filter: index < filledAnts ? 'none' : 'grayscale(100%)',
                }}
              >
                🐜
              </motion.span>
            ))}
          </div>
        </div>
      </div>

      {/* Loading Text */}
      <motion.h2
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-2xl text-black"
      >
        Loading, please wait!
      </motion.h2>
    </div>
  );
}
