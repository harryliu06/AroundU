
  # Create loading screen design

  This is a code bundle for Create loading screen design. The original project is available at https://www.figma.com/design/3CLnutqCc8v5o8kgFbfSXh/Create-loading-screen-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  