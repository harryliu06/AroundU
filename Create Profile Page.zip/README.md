
  # Create Profile Page

  This is a code bundle for Create Profile Page. The original project is available at https://www.figma.com/design/FwhVxTa3SRJb7G1YIeVUuu/Create-Profile-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  