import { ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-gray-50">
      {/* Mobile Phone Frame */}
      <div className="w-full max-w-sm h-full max-h-[844px] bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Cover Photo with Back Button */}
        <div className="relative h-48">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1559310589-2673bfe16970?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBsYW5kc2NhcGUlMjBtb3VudGFpbnMlMjBsYWtlfGVufDF8fHx8MTc3OTkzNTU1MXww&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Cover photo"
            className="w-full h-full object-cover"
          />

          {/* Back Button */}
          <button className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        {/* Profile Content */}
        <div className="flex-1 overflow-y-auto px-6 pb-6">
          {/* Profile Picture */}
          <div className="flex justify-center -mt-16 mb-4">
            <div className="w-32 h-32 rounded-full border-4 border-white shadow-lg overflow-hidden bg-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHBlcnNvbnxlbnwxfHx8fDE3Nzk5MzU1NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Profile picture"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Name */}
          <h1 className="text-center text-xl font-semibold text-gray-900 mb-4">
            Harley Quizel
          </h1>

          {/* Action Buttons */}
          <div className="flex gap-2 mb-4">
            <button className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg font-medium">
              Friend Request
            </button>
            <button className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg font-medium">
              Block User
            </button>
          </div>

          <div className="flex mb-6">
            <button className="flex-1 px-4 py-2 bg-cyan-400 text-white rounded-lg font-medium">
              Message Request
            </button>
          </div>

          {/* Bio Section */}
          <div className="mb-6">
            <h2 className="font-semibold text-gray-900 mb-2">Bio:</h2>
            <p className="text-gray-700 text-sm leading-relaxed">
              Hello, my name is Harley Quizel. I love riding my bikes on Friday evenings and playing guitar over the weekends, making new tracks on my YouTube Channel.
            </p>
          </div>

          {/* Tags Section */}
          <div className="mb-6">
            <h2 className="font-semibold text-gray-900 mb-2">Tags:</h2>
            <p className="text-sm text-blue-500">
              #Biking, #Music, #YouTube, #Horror Films, #forco...
            </p>
          </div>

          {/* Photo Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1716827172152-88f9c935c871?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWZlc3R5bGUlMjBwaG90b2dyYXBoeSUyMGNhc3VhbHxlbnwxfHx8fDE3Nzk5MzU1NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Gallery photo 1"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1754799670342-65e4a4a06f2a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxsaWZlc3R5bGUlMjBwaG90b2dyYXBoeSUyMGNhc3VhbHxlbnwxfHx8fDE3Nzk5MzU1NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Gallery photo 2"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1716827172675-6a3030fd1560?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxsaWZlc3R5bGUlMjBwaG90b2dyYXBoeSUyMGNhc3VhbHxlbnwxfHx8fDE3Nzk5MzU1NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Gallery photo 3"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
