
  # Settings page

  This is a code bundle for Settings page. The original project is available at https://www.figma.com/design/5nkH0dIWW1EheDRMtYtL7C/Settings-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  