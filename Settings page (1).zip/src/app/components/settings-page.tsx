import { useState } from 'react';
import { ArrowLeft, ChevronRight, ChevronUp, User, Languages, Type, Volume2 } from 'lucide-react';
import { Switch } from './ui/switch';
import { Button } from './ui/button';

export function SettingsPage() {
  const [locationSharingExpanded, setLocationSharingExpanded] = useState(false);
  const [cameraAccess, setCameraAccess] = useState(true);
  const [microphoneAccess, setMicrophoneAccess] = useState(false);
  const [storageAccess, setStorageAccess] = useState(true);
  const [selectedLocationOption, setSelectedLocationOption] = useState<string | null>(null);

  const locationOptions = [
    'Disable:',
    'Until I turn it on',
    'For 1 hour',
    'For 2 hours',
    'For 4 hours'
  ];

  return (
    <div className="w-full max-w-md h-[800px] bg-[#e8f4f5] rounded-[40px] border-8 border-black shadow-2xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="bg-white px-4 py-4 flex items-center gap-3 border-b border-gray-200">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-lg tracking-wide">SETTINGS</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 bg-[#ffffff]">
        {/* General Section */}
        <div className="mb-4">
          <div className="bg-gray-300 px-3 py-1.5 mb-2">
            <h2 className="text-sm">General</h2>
          </div>
          <button className="w-full bg-white px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="bg-white border-2 border-black rounded-full p-1">
                <User className="h-5 w-5" />
              </div>
              <span className="text-sm tracking-wide">ACCOUNT SETTINGS</span>
            </div>
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Language Settings Section */}
        <div className="mb-4">
          <div className="bg-gray-300 px-3 py-1.5 mb-2">
            <h2 className="text-sm">Language Settings</h2>
          </div>
          <button className="w-full bg-white px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
            <div className="flex items-center gap-3">
              <Languages className="h-6 w-6" />
              <span className="text-sm tracking-wide text-left">LANGUAGE OPTION</span>
            </div>
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Accessibility Section */}
        <div className="mb-4">
          <div className="bg-gray-300 px-3 py-1.5 mb-2">
            <h2 className="text-sm">Accessibility</h2>
          </div>
          <div className="bg-white">
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-200">
              <div className="flex items-center gap-3">
                <Type className="h-6 w-6" />
                <span className="text-sm tracking-wide text-left">INCREASE TEXT SIZE</span>
              </div>
              <ChevronRight className="h-5 w-5" />
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-3">
                <Volume2 className="h-6 w-6" />
                <span className="text-sm tracking-wide text-left">VOICE OVER</span>
              </div>
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Permissions Section */}
        <div className="mb-4">
          <div className="bg-gray-300 px-3 py-1.5 mb-2">
            <h2 className="text-sm">Permissions</h2>
          </div>
          <div className="bg-white">
            {/* Location Sharing */}
            <div>
              <button
                onClick={() => setLocationSharingExpanded(!locationSharingExpanded)}
                className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-200"
              >
                <span className="text-sm tracking-wide text-left font-normal">LOCATION SHARING</span>
                <ChevronUp
                  className={`h-5 w-5 transition-transform ${
                    locationSharingExpanded ? 'rotate-0' : 'rotate-180'
                  }`}
                />
              </button>
              {locationSharingExpanded && (
                <div className="px-4 py-4 bg-gray-300 border-b border-gray-200">
                  <div className="space-y-0.5">
                    {locationOptions.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedLocationOption(option)}
                        className={`block w-full text-left px-3 py-1 text-sm hover:bg-gray-400 transition-colors ${
                          selectedLocationOption === option ? 'bg-gray-400' : ''
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Camera Access */}
            <div className="px-4 py-4 flex items-center justify-between border-b border-gray-200">
              <span className="tracking-wide text-left text-[14px]">ALLOW CAMERA ACCESS</span>
              <Switch checked={cameraAccess} onCheckedChange={setCameraAccess} />
            </div>

            {/* Microphone Access */}
            <div className="px-4 py-4 flex items-center justify-between border-b border-gray-200">
              <span className="tracking-wide text-left text-[14px]">ALLOW MICROPHONE ACCESS</span>
              <Switch checked={microphoneAccess} onCheckedChange={setMicrophoneAccess} />
            </div>

            {/* Files/Storage Permission */}
            <div className="px-4 py-4 flex items-center justify-between">
              <span className="tracking-wide text-left text-[14px]">ALLOW FILES/STORAGE ACCESS</span>
              <Switch checked={storageAccess} onCheckedChange={setStorageAccess} />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom indicator */}
      <div className="bg-white py-2 flex justify-center">
        <div className="w-32 h-1 bg-black rounded-full" />
      </div>
    </div>
  );
}
