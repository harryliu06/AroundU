import { SettingsPage } from './components/settings-page';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      <SettingsPage />
    </div>
  );
}
