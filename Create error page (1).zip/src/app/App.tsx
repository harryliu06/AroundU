import { MapPin } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

export default function App() {
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    // Trigger animation after component mounts
    setShowAnimation(true);
  }, []);

  return (
    <div className="size-full flex flex-col items-center justify-center bg-gray-50 relative overflow-hidden">
      {/* Mobile device frame outline */}
      <div className="relative w-full max-w-md h-[calc(100vh-4rem)] border-8 border-black rounded-[3rem] overflow-hidden bg-white shadow-2xl">
        {/* Back button */}
        <div className="absolute top-4 left-4 z-10">
          <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m15 18-6-6 6-6" />
            </svg>
          </button>
        </div>

        {/* Main content */}
        <div className="relative h-full flex flex-col items-center justify-center px-8">
          {/* Location pin - destination */}
          <motion.div
            className="absolute"
            style={{
              top: '25%',
              right: '20%',
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={showAnimation ? { scale: 1, opacity: 1 } : {}}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <MapPin className="w-10 h-10 text-blue-400 fill-blue-400" />
          </motion.div>

          {/* Ant trail following the path */}
          <svg
            className="absolute"
            style={{
              top: '25%',
              left: '20%',
              width: '60%',
              height: '30%',
            }}
            viewBox="0 0 300 150"
            fill="none"
          >
            {/* Ants marching along the curved path */}
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => {
              const t = i / 12;
              // Calculate position along the curved path
              const x = t < 0.5
                ? 0 + (150 * (t * 2))
                : 150 + (130 * ((t - 0.5) * 2));
              const y = t < 0.5
                ? 140 - (80 * (t * 2))
                : 60 - (50 * ((t - 0.5) * 2));

              return (
                <motion.g
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={showAnimation ? { opacity: 1 } : {}}
                  transition={{ delay: 0.1 * i, duration: 0.3 }}
                >
                  {/* Ant body */}
                  <ellipse cx={x} cy={y} rx="4" ry="5" fill="#1F1F1F" />
                  <ellipse cx={x} cy={y - 6} rx="3.5" ry="4" fill="#2C2C2C" />
                  <ellipse cx={x} cy={y + 6} rx="4.5" ry="5.5" fill="#1F1F1F" />
                  {/* Ant legs */}
                  <line x1={x - 3} y1={y} x2={x - 5} y2={y + 3} stroke="#1F1F1F" strokeWidth="0.8" />
                  <line x1={x + 3} y1={y} x2={x + 5} y2={y + 3} stroke="#1F1F1F" strokeWidth="0.8" />
                  <line x1={x - 2} y1={y + 3} x2={x - 4} y2={y + 6} stroke="#1F1F1F" strokeWidth="0.8" />
                  <line x1={x + 2} y1={y + 3} x2={x + 4} y2={y + 6} stroke="#1F1F1F" strokeWidth="0.8" />
                  {/* Ant antennae */}
                  <line x1={x - 1} y1={y - 9} x2={x - 2} y2={y - 11} stroke="#1F1F1F" strokeWidth="0.6" />
                  <line x1={x + 1} y1={y - 9} x2={x + 2} y2={y - 11} stroke="#1F1F1F" strokeWidth="0.6" />
                </motion.g>
              );
            })}
          </svg>

          {/* Falling tired anteater (upside-down) */}
          <motion.div
            className="mb-8"
            initial={{ y: -200, rotate: 160, opacity: 0 }}
            animate={
              showAnimation
                ? {
                    y: 0,
                    rotate: [180, 195, 175, 185, 180],
                    opacity: 1
                  }
                : {}
            }
            transition={{
              y: { duration: 1.5, ease: "easeOut" },
              rotate: { duration: 2, ease: "easeInOut" },
              opacity: { duration: 0.5 }
            }}
          >
            {/* Anteater SVG illustration (upside-down and tired) */}
            <svg
              width="200"
              height="120"
              viewBox="0 0 200 120"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Main body */}
              <ellipse cx="100" cy="60" rx="45" ry="35" fill="#8B7355" />

              {/* Head with long snout */}
              <ellipse cx="60" cy="55" rx="20" ry="18" fill="#A0826D" />

              {/* Long snout/nose */}
              <path
                d="M 50 55 Q 30 55, 20 55 L 18 57 L 20 59 Q 30 59, 50 59 Z"
                fill="#6B5744"
              />

              {/* Tired eyes (X X) */}
              <g>
                <line x1="54" y1="50" x2="58" y2="54" stroke="#2C2C2C" strokeWidth="2" strokeLinecap="round" />
                <line x1="58" y1="50" x2="54" y2="54" stroke="#2C2C2C" strokeWidth="2" strokeLinecap="round" />
                <line x1="62" y1="50" x2="66" y2="54" stroke="#2C2C2C" strokeWidth="2" strokeLinecap="round" />
                <line x1="66" y1="50" x2="62" y2="54" stroke="#2C2C2C" strokeWidth="2" strokeLinecap="round" />
              </g>

              {/* Ear */}
              <ellipse cx="70" cy="48" rx="8" ry="12" fill="#8B7355" />

              {/* Bushy tail */}
              <path
                d="M 135 65 Q 150 60, 165 55 Q 175 52, 180 55 Q 175 60, 165 63 Q 150 68, 135 70 Z"
                fill="#5C4535"
              />
              <path
                d="M 140 60 Q 155 55, 170 50 Q 178 48, 183 50 Q 178 55, 168 58 Q 153 63, 140 65 Z"
                fill="#6B5744"
              />

              {/* Legs (short and stubby) */}
              <ellipse cx="80" cy="88" rx="8" ry="15" fill="#8B7355" />
              <ellipse cx="100" cy="90" rx="8" ry="15" fill="#8B7355" />
              <ellipse cx="120" cy="88" rx="8" ry="15" fill="#8B7355" />

              {/* Claws on feet */}
              <line x1="75" y1="100" x2="73" y2="105" stroke="#3F3F3F" strokeWidth="2" strokeLinecap="round" />
              <line x1="80" y1="100" x2="80" y2="106" stroke="#3F3F3F" strokeWidth="2" strokeLinecap="round" />
              <line x1="85" y1="100" x2="87" y2="105" stroke="#3F3F3F" strokeWidth="2" strokeLinecap="round" />

              {/* Belly marking */}
              <ellipse cx="95" cy="65" rx="25" ry="20" fill="#C4A57B" opacity="0.6" />
            </svg>
          </motion.div>

          {/* Error message */}
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={showAnimation ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 1, duration: 0.5 }}
          >
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Uh Oh! Something went wrong
            </h1>
            <p className="text-lg text-gray-700">
              Please check back in later.
            </p>
          </motion.div>
        </div>

        {/* Bottom notch/home indicator */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-black rounded-full" />
      </div>
    </div>
  );
}
