
  # Create error page

  This is a code bundle for Create error page. The original project is available at https://www.figma.com/design/J1Gy2aIhD1CtIOiGrQPiUS/Create-error-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  